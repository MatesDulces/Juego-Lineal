package papu;

import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;

public class gatito extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel gatonegro;
    private ImageIcon idleIcon;
    private ImageIcon movingIcon;
    private int playerSpeed = 5;
    private int gravity = 1;
    private int jumpStrength = 15;
    private int velocityY = 0;
    private int velocityX = 0;
    private boolean jumping = false;
    private boolean onGround = true;
    private Timer gameTimer;
    private boolean isMoving = false;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                gatito frame = new gatito();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public gatito() {
        // Set up the JFrame to be maximized
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(false); // Ensure the window has borders and title bar

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        // Load images
        idleIcon = new ImageIcon(getClass().getResource("/image/3.png"));
        movingIcon = new ImageIcon(getClass().getResource("/image/gatogif.gif"));

        // Initialize the JLabel with the size of the GIF
        int gifWidth = movingIcon.getIconWidth();
        int gifHeight = movingIcon.getIconHeight();
        
        gatonegro = new JLabel();
        gatonegro.setBounds(35, 403, gifWidth, gifHeight);
        contentPane.add(gatonegro);

        // Set the initial icon
        gatonegro.setIcon(idleIcon);

        contentPane.setFocusable(true);
        contentPane.requestFocusInWindow();

        contentPane.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                    velocityX = -playerSpeed;
                    gatonegro.setIcon(movingIcon);
                    isMoving = true;
                } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                    velocityX = playerSpeed;
                    gatonegro.setIcon(movingIcon);
                    isMoving = true;
                } else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                    if (onGround) {
                        velocityY = -jumpStrength;
                        jumping = true;
                        onGround = false;
                    }
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_RIGHT) {
                    velocityX = 0;
                    isMoving = false;
                    gatonegro.setIcon(idleIcon);
                }
            }
        });

        gameTimer = new Timer(5, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                applyGravity();
                updatePosition();
                checkCollision();
                if (!isMoving) {
                    gatonegro.setIcon(idleIcon);
                }
            }
        });
        gameTimer.start();
    }

    private void applyGravity() {
        if (!onGround) {
            velocityY += gravity;
        }
    }

    private void updatePosition() {
        int x = gatonegro.getX() + velocityX;
        int y = gatonegro.getY() + velocityY;
        gatonegro.setLocation(x, y);
    }

    private void checkCollision() {
        int x = gatonegro.getX();
        int y = gatonegro.getY();
        int frameHeight = contentPane.getHeight();
        int frameWidth = contentPane.getWidth();
        int playerHeight = gatonegro.getHeight();
        int playerWidth = gatonegro.getWidth();

        // Ground collision
        if (y + playerHeight > frameHeight) {
            gatonegro.setLocation(x, frameHeight - playerHeight);
            velocityY = 5;
            onGround = true;
            jumping = false;
        }

        // Ceiling collision (if needed)
        if (y < 0) {
            gatonegro.setLocation(x, 0);
            velocityY = 5;
            jumping = false;
        }

        // Wall collision (left and right)
        if (x < 0) {
            gatonegro.setLocation(0, y);
        } else if (x + playerWidth > frameWidth) {
            gatonegro.setLocation(frameWidth - playerWidth, y);
        }
    }
}

package papu;

import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class INICIO extends JFrame {
	private gatito gatito;
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    INICIO frame = new INICIO();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public INICIO() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null); // Usar null layout para establecer el tamaño del JLabel manualmente
        setContentPane(contentPane);
        
        // Crear y ajustar JLabel
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setBounds(0, 0, 1920, 1057); // Establecer el tamaño del JLabel (ajusta según sea necesario)
        contentPane.add(lblNewLabel);
        gatito = new gatito ();
        // Cargar la imagen y escalarla al tamaño del JLabel
        ImageIcon originalIcon = new ImageIcon(INICIO.class.getResource("/image/imagen1.png"));
        Image originalImage = originalIcon.getImage();
        Image scaledImage = originalImage.getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        // Establecer la imagen escalada como icono del JLabel
        lblNewLabel.setIcon(scaledIcon);
    }
    public gatito getgatito() {
        return gatito;
    }
}

import javax.swing.*;
import java.awt.*;

public class Obstaculo extends JPanel {
    private int worldX; // Posición del obstáculo en el mundo

    public Obstaculo(int x, int y) {
        setBackground(Color.RED);
        setBounds(x, y, 50, 50);
        this.worldX = x; // Posición inicial en el mundo
    }

    // Método para obtener la posición en el mundo
    public int getWorldX() {
        return worldX;
    }

    // Método para detectar colisión entre el jugador y el obstáculo
    public boolean detectCollision(Player player) {
        Rectangle playerBounds = player.getBounds();
        Rectangle obstacleBounds = getBounds();
        return playerBounds.intersects(obstacleBounds);
    }
}

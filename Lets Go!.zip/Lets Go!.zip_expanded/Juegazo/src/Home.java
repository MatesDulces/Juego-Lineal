import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyEvent;

public class Home extends JFrame {

    private JPanel contentPane;
    private JButton startButton;
    private JButton quitButton;
    private int selectedIndex = 0;
    private Timer blinkTimer;
    private boolean isBlinking = false;
    private JLabel leftEmoji;
    private JLabel rightEmoji;
    private JLabel lblNewLabel;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Home frame = new Home();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Home() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1011, 414);
        contentPane = new JPanel();
        contentPane.setBackground(Color.CYAN);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        leftEmoji = new JLabel("-");
        leftEmoji.setBackground(Color.BLUE);
        leftEmoji.setForeground(Color.BLUE);
        rightEmoji = new JLabel("-");
        rightEmoji.setBackground(Color.BLUE);
        rightEmoji.setForeground(Color.BLUE);
        leftEmoji.setFont(new Font("Arial", Font.PLAIN, 30));
        rightEmoji.setFont(new Font("Arial", Font.PLAIN, 30));
        contentPane.add(leftEmoji);
        contentPane.add(rightEmoji);

        startButton = createButton("EMPIEZA YA!", 405, 150);
        quitButton = createButton("SALIR YA", 405, 220);

        contentPane.add(startButton);
        contentPane.add(quitButton);
       
        JPanel panel = new JPanel();
        panel.setBackground(Color.GREEN);
        panel.setBounds(-14, 328, 1022, 59);
        contentPane.add(panel);
       
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(Color.BLUE);
        panel_1.setBounds(36, 278, 57, 51);
        contentPane.add(panel_1);
       
        lblNewLabel = new JLabel("");
        lblNewLabel.setIcon(new ImageIcon(Home.class.getResource("/imagenes/-Lets-Go-Little-Cube (1).png")));
        lblNewLabel.setBounds(104, 22, 891, 104);
        contentPane.add(lblNewLabel);

        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                handleKeyPress(evt);
            }
        });

        setFocusable(true);
        requestFocusInWindow();
        updateButtonSelection();
    }

    private JButton createButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 200, 50);
        button.setOpaque(true);
        button.setForeground(Color.RED);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setBackground(Color.BLUE);
        return button;
    }

    private void handleKeyPress(KeyEvent evt) {
        switch (evt.getKeyCode()) {
            case KeyEvent.VK_UP:
            case KeyEvent.VK_DOWN:
                selectNextButton();
                break;
            case KeyEvent.VK_ENTER:
                if (selectedIndex == 0) {
                    startGame();
                } else {
                    quitGame();
                }
                break;
        }
    }

    private void selectNextButton() {
        selectedIndex = (selectedIndex == 0) ? 1 : 0;
        updateButtonSelection();
    }

    private void updateButtonSelection() {
        if (blinkTimer != null) {
            blinkTimer.stop();
        }

        JButton selectedButton = (selectedIndex == 0) ? startButton : quitButton;

        // Actualizar posici�n de los emojis
        int buttonY = selectedButton.getY();
        leftEmoji.setBounds(390, buttonY, 50, 50);
        rightEmoji.setBounds(600, buttonY, 50, 50);

        blinkTimer = new Timer(400, e -> {
            if (isBlinking) {
                selectedButton.setForeground(Color.BLUE);
            } else {
                selectedButton.setForeground(Color.RED);
            }
            isBlinking = !isBlinking;
        });
        blinkTimer.start();

        startButton.setForeground(selectedIndex == 0 ? Color.BLUE : Color.RED);
        quitButton.setForeground(selectedIndex == 1 ? Color.BLUE : Color.RED);

        repaint(); // Asegurarse de que los cambios se muestren inmediatamente
    }

    private void startGame() {
        EventQueue.invokeLater(() -> {
            Background background = new Background();
            background.setVisible(true);
            dispose();
        });
    }

    private void quitGame() {
        System.exit(0);
    }
}
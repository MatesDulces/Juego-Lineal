import javax.swing.*;
import java.awt.*;

public class DisparoCeleste extends JLabel {
    public static final int WIDTH = 10; // Cambiado a public
    public static final int HEIGHT = 20; // Cambiado a public
    private int worldX;
    private int worldY;
    private int speed = 5;

    public DisparoCeleste(int x) {
        this.worldX = x;
        this.worldY = 0; // Comienza en la parte superior
        setBounds(worldX, worldY, WIDTH, HEIGHT);
        setBackground(Color.BLUE);
        setOpaque(true);
    }

    public void update() {
        worldY += speed;
        setLocation(worldX, worldY);
    }

    public boolean isOffScreen() {
        return worldY > 414; // Fuera de la pantalla
    }

    public boolean detectCollision(Player player) {
        Rectangle disparoBounds = new Rectangle(worldX, worldY, WIDTH, HEIGHT);
        Rectangle playerBounds = new Rectangle(player.getWorldX(), player.getY(), player.getWidth(), player.getHeight());
        return disparoBounds.intersects(playerBounds);
    }
}

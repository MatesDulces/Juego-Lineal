import javax.swing.JPanel;
import java.awt.Color;

public class Player extends JPanel {
    private int worldX;
    private double velocityX = 0;
    private double velocityY = 0;
    private final double GRAVITY = 0.5;
    private final double JUMP_POWER = -10;
    private final double NORMAL_SPEED = 5;
    private final double SPRINT_SPEED = 10;
    private double currentSpeed = NORMAL_SPEED;
    private boolean jumping = false;
    private final int FLOOR_Y;
    private final int WORLD_WIDTH;
    private boolean sprinting = false;

    public Player(int worldWidth, int floorY) {
        setBackground(Color.BLUE);
        setSize(40, 40);
        this.WORLD_WIDTH = worldWidth;
        this.FLOOR_Y = floorY;
        this.worldX = 100; // Starting position
    }

    public void update() {
        worldX += velocityX;
        worldX = Math.max(0, Math.min(worldX, WORLD_WIDTH - 1)); // Allow reaching the right edge

        velocityY += GRAVITY;
        
        int newY = (int) (getY() + velocityY);
        if (newY + getHeight() > FLOOR_Y) {
            newY = FLOOR_Y - getHeight();
            velocityY = 0;
            jumping = false;
        }
        
        setLocation(getX(), newY);
    }

    public void moveLeft() {
        velocityX = -currentSpeed;
    }

    public void moveRight() {
        velocityX = currentSpeed;
    }

    public void stopHorizontalMovement() {
        velocityX = 0;
    }

    public void jump() {
        if (!jumping && getY() + getHeight() == FLOOR_Y) {
            velocityY = JUMP_POWER;
            jumping = true;
        }
    }

    public void startSprint() {
        sprinting = true;
        currentSpeed = SPRINT_SPEED;
        if (velocityX != 0) {
            velocityX = velocityX > 0 ? currentSpeed : -currentSpeed;
        }
    }

    public void stopSprint() {
        sprinting = false;
        currentSpeed = NORMAL_SPEED;
        if (velocityX != 0) {
            velocityX = velocityX > 0 ? currentSpeed : -currentSpeed;
        }
    }

    public int getWorldX() {
        return worldX;
    }

    public void setWorldX(int x) {
        this.worldX = x;
    }

    public double getVelocityX() {
        return velocityX;
    }

    public double getVelocityY() {
        return velocityY;
    }

    public void setVelocityY(double velocityY) {
        this.velocityY = velocityY;
    }

    public boolean isJumping() {
        return jumping;
    }

    public void setJumping(boolean jumping) {
        this.jumping = jumping;
    }

    public boolean isSprinting() {
        return sprinting;
    }
}

import javax.swing.*;
import java.awt.*;

public class Meta extends JPanel {
    private int worldX; // Posición de la meta en el mundo

    public Meta(int x, int y) {
        setBackground(Color.YELLOW); // Color de la meta
        setBounds(x, y, 50, 50); // Tamaño de la meta
        this.worldX = x; // Posición inicial en el mundo
    }

    // Método para obtener la posición en el mundo
    public int getWorldX() {
        return worldX;
    }

    // Método para detectar colisión entre el jugador y la meta
    public boolean detectCollision(Player player) {
        Rectangle playerBounds = player.getBounds();
        Rectangle metaBounds = getBounds();
        return playerBounds.intersects(metaBounds);
    }
}

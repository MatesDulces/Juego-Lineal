import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class Background4 extends JFrame {

    private JPanel contentPane;
    private Player player;
    private JPanel floorPanel;
    private ArrayList<Obstaculo> obstacles;
    private ArrayList<Moneda> monedas;
    private Meta meta;
    private int lives = 3;
    private int coinsCollected = 0;
    private JLabel livesLabel;
    private JLabel coinsLabel;
    private int worldOffsetX = 0;
    private static final int VIEWPORT_WIDTH = 1011;
    private static final int VIEWPORT_HEIGHT = 414;
    private static final int WORLD_WIDTH = 2000;
    private static final int FLOOR_Y = 319;
    private boolean gameWon = false;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Background4 frame = new Background4();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Background4() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, VIEWPORT_WIDTH, VIEWPORT_HEIGHT);
        contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setColor(Color.MAGENTA);
                g2d.fillRect(-worldOffsetX, 0, WORLD_WIDTH, VIEWPORT_HEIGHT);
                
                if (gameWon) {
                    g2d.setColor(Color.BLACK);
                    g2d.setFont(new Font("Arial", Font.BOLD, 48));
                    FontMetrics fm = g2d.getFontMetrics();
                    String winMessage = "LEVEL 4 COMPLETE!";
                    int messageWidth = fm.stringWidth(winMessage);
                    g2d.drawString(winMessage, (VIEWPORT_WIDTH - messageWidth) / 2, VIEWPORT_HEIGHT / 2);
                }
            }
        };
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        floorPanel = new JPanel();
        floorPanel.setBackground(Color.GREEN);
        floorPanel.setBounds(-worldOffsetX, FLOOR_Y, WORLD_WIDTH, VIEWPORT_HEIGHT - FLOOR_Y);
        contentPane.add(floorPanel);

        player = new Player(WORLD_WIDTH, FLOOR_Y);
        contentPane.add(player);

        // Crear varios obstáculos y añadirlos a la lista
        obstacles = new ArrayList<>();
        Obstaculo obstacle1 = new Obstaculo(400, FLOOR_Y - 50);
        Obstaculo obstacle2 = new Obstaculo(800, FLOOR_Y - 50);
        Obstaculo obstacle3 = new Obstaculo(1200, FLOOR_Y - 50);
        obstacles.add(obstacle1);
        obstacles.add(obstacle2);
        obstacles.add(obstacle3);
        
        for (Obstaculo obstaculo : obstacles) {
            contentPane.add(obstaculo);
        }

        // Crear varias monedas y añadirlas a la lista
        monedas = new ArrayList<>();
        Moneda moneda1 = new Moneda(500, FLOOR_Y - 100);
        Moneda moneda2 = new Moneda(600, FLOOR_Y - 100);
        Moneda moneda3 = new Moneda(700, FLOOR_Y - 100);
        Moneda moneda4 = new Moneda(900, FLOOR_Y - 100);
        Moneda moneda5 = new Moneda(1000, FLOOR_Y - 100);
        Moneda moneda6 = new Moneda(1100, FLOOR_Y - 100);
        monedas.add(moneda1);
        monedas.add(moneda2);
        monedas.add(moneda3);
        monedas.add(moneda4);
        monedas.add(moneda5);
        monedas.add(moneda6);
        
        for (Moneda moneda : monedas) {
            contentPane.add(moneda);
        }

        // Crear y añadir la meta al final del nivel
        meta = new Meta(WORLD_WIDTH - 100, FLOOR_Y - 50);
        contentPane.add(meta);

        livesLabel = new JLabel("Vidas: " + lives);
        livesLabel.setFont(new Font("Arial", Font.BOLD, 20));
        livesLabel.setBounds(10, 10, 100, 30);
        contentPane.add(livesLabel);
        
        // Añadir un JLabel para mostrar las monedas recolectadas
        coinsLabel = new JLabel("Monedas: " + coinsCollected);
        coinsLabel.setFont(new Font("Arial", Font.BOLD, 20));
        coinsLabel.setBounds(120, 10, 150, 30);
        contentPane.add(coinsLabel);

        Timer gameTimer = new Timer(16, e -> {
            if (!gameWon) {
                updateWorld();
                checkCollision();
                checkCoinCollection();
                checkWinCondition();
                contentPane.repaint();
            }
        });
        gameTimer.start();

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (!gameWon) {
                    switch (e.getKeyCode()) {
                        case KeyEvent.VK_LEFT:
                            player.moveLeft();
                            break;
                        case KeyEvent.VK_RIGHT:
                            player.moveRight();
                            break;
                        case KeyEvent.VK_SPACE:
                            player.jump();
                            break;
                        case KeyEvent.VK_CONTROL:
                            player.startSprint();
                            break;
                    }
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (!gameWon) {
                    switch (e.getKeyCode()) {
                        case KeyEvent.VK_LEFT:
                        case KeyEvent.VK_RIGHT:
                            player.stopHorizontalMovement();
                            break;
                        case KeyEvent.VK_CONTROL:
                            player.stopSprint();
                            break;
                    }
                }
            }
        });

        setFocusable(true);
        requestFocusInWindow();
    }

    private void updateWorld() {
        player.update();

        // Update camera position
        int playerScreenX = player.getWorldX() - worldOffsetX;
        if (playerScreenX < VIEWPORT_WIDTH / 4) {
            worldOffsetX = Math.max(0, player.getWorldX() - VIEWPORT_WIDTH / 4);
        } else if (playerScreenX > VIEWPORT_WIDTH * 3 / 4) {
            worldOffsetX = Math.min(WORLD_WIDTH - VIEWPORT_WIDTH, player.getWorldX() - VIEWPORT_WIDTH * 3 / 4);
        }

        // Update player, obstacles, and coins positions on screen
        player.setLocation(player.getWorldX() - worldOffsetX, player.getY());
        
        for (Obstaculo obstaculo : obstacles) {
            obstaculo.setLocation(obstaculo.getWorldX() - worldOffsetX, obstaculo.getY());
        }

        for (Moneda moneda : monedas) {
            moneda.setLocation(moneda.getWorldX() - worldOffsetX, moneda.getY());
        }

        // Update meta position on screen
        meta.setLocation(meta.getWorldX() - worldOffsetX, meta.getY());

        // Update world elements
        floorPanel.setLocation(-worldOffsetX, FLOOR_Y);
    }

    private void checkCollision() {
        for (Obstaculo obstaculo : obstacles) {
            if (obstaculo.detectCollision(player)) {
                lives--;
                if (lives > 0) {
                    resetLevel();
                } else {
                    gameOver();
                }
                break;
            }
        }
    }

    private void checkCoinCollection() {
        ArrayList<Moneda> monedasRecolectadas = new ArrayList<>();
        for (Moneda moneda : monedas) {
            if (moneda.detectCollision(player)) {
                monedasRecolectadas.add(moneda);
            }
        }
        for (Moneda moneda : monedasRecolectadas) {
            monedas.remove(moneda);
            contentPane.remove(moneda);
            coinsCollected++;
            coinsLabel.setText("Monedas: " + coinsCollected);
        }
    }

    private void checkWinCondition() {
        if (meta.detectCollision(player)) {
            gameWon = true;
            Timer transitionTimer = new Timer(1000, e -> {
                ((Timer) e.getSource()).stop();
                dispose(); // Cerrar la ventana del nivel actual
                new Background5().setVisible(true);
            });
            transitionTimer.setRepeats(false);
            transitionTimer.start();
        }
    }

    private void gameOver() {
        JOptionPane.showMessageDialog(this, "Perdiste todas tus vidas. ¡Fin del juego!");
        System.exit(0);
    }

    private void resetLevel() {
        player.setWorldX(100);
        player.setVelocityY(0);
        player.setLocation(100, FLOOR_Y - player.getHeight());
        livesLabel.setText("Vidas: " + lives);
    }
}

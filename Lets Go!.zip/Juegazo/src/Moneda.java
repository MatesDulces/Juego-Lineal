import javax.swing.*;
import java.awt.*;

public class Moneda extends JPanel {
    private int worldX; // Posición de la moneda en el mundo

    public Moneda(int x, int y) {
        setBackground(Color.ORANGE); // Color de la moneda
        setBounds(x, y, 30, 30); // Tamaño de la moneda
        this.worldX = x; // Posición inicial en el mundo
    }

    // Método para obtener la posición en el mundo
    public int getWorldX() {
        return worldX;
    }

    // Método para detectar colisión entre el jugador y la moneda
    public boolean detectCollision(Player player) {
        Rectangle playerBounds = player.getBounds();
        Rectangle monedaBounds = getBounds();
        return playerBounds.intersects(monedaBounds);
    }
}

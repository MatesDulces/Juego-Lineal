import javax.swing.*;
import java.awt.*;

public class Enemigo extends JPanel {
    private int worldX;
    private int worldY;
    private int width = 50;
    private int height = 50;
    private boolean alive = true;
    private int speed = 2;

    public Enemigo(int x, int y) {
        this.worldX = x;
        this.worldY = y;
        setBounds(worldX, worldY, width, height);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (alive) {
            g.setColor(Color.MAGENTA);
            g.fillRect(0, 0, width, height);
        }
    }

    public void die() {
        alive = false;
        setVisible(false);
        repaint();
    }

    public boolean isAlive() {
        return alive;
    }

    public int getWorldX() {
        return worldX;
    }

    public int getWorldY() {
        return worldY;
    }

    public void update() {
        if (alive) {
            worldX -= speed;
            setLocation(worldX, worldY);
        }
    }

    public boolean detectCollision(Player player) {
        Rectangle enemyBounds = new Rectangle(worldX, worldY, width, height);
        Rectangle playerBounds = new Rectangle(player.getWorldX(), player.getY(), player.getWidth(), player.getHeight());
        return enemyBounds.intersects(playerBounds);
    }

    public boolean checkJumpCollision(Player player) {
        if (detectCollision(player)) {
            return player.getY() + player.getHeight() <= worldY + 10 && player.getVelocityY() > 0;
        }
        return false;
    }

    public boolean checkSideCollision(Player player) {
        if (detectCollision(player)) {
            return player.getY() + player.getHeight() > worldY + 10;
        }
        return false;
    }
}
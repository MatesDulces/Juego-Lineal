import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

public class Home extends JFrame {

    private JPanel contentPane;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Home frame = new Home();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Home() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1011, 414);
        contentPane = new JPanel();
        contentPane.setBackground(Color.PINK);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JButton startButton = new JButton("Iniciar Juego");
        startButton.setBounds(400, 170, 200, 50);
        contentPane.add(startButton);

        // Configurar el botón para que no tenga bordes
        startButton.setBorderPainted(false);
        startButton.setFocusPainted(false);
        startButton.setContentAreaFilled(false); // Quitar el fondo del botón

        // Personalizar el botón
        startButton.setOpaque(true);
        startButton.setBackground(Color.PINK); // Color de fondo
        startButton.setForeground(Color.WHITE); // Color del texto
        startButton.setFont(new Font("Arial", Font.BOLD, 16)); // Fuente del texto

        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startGame();
            }
        });

        // Configurar el acceso mediante teclado
        startButton.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "startGame");
        startButton.getActionMap().put("startGame", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startGame();
            }
        });

        setFocusable(true);
        requestFocusInWindow();
    }

    private void startGame() {
        // Cambiar a la ventana del primer nivel
        EventQueue.invokeLater(() -> {
            Background background = new Background();
            background.setVisible(true);
            dispose(); // Cerrar la ventana de inicio
        });
    }
}

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class Background3 extends JFrame {

    private JPanel contentPane;
    private Player player;
    private JPanel floorPanel;
    private ArrayList<Obstaculo> obstacles;
    private ArrayList<Moneda> monedas;
    private Meta meta;
    private int lives = 3;
    private int coinsCollected = 0;
    private JLabel livesLabel;
    private JLabel coinsLabel;
    private int worldOffsetX = 0;
    private static final int VIEWPORT_WIDTH = 1011;
    private static final int VIEWPORT_HEIGHT = 414;
    private static final int WORLD_WIDTH = 2000;
    private static final int FLOOR_Y = 319;
    private boolean gameWon = false;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Background3 frame = new Background3();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Background3() {
        setupFrame();
        initializeComponents();
        setupGameLoop();
        setupKeyBindings();
    }

    private void setupFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, VIEWPORT_WIDTH, VIEWPORT_HEIGHT);
        contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setColor(Color.CYAN); // Cambié el color de fondo a azul claro
                g2d.fillRect(-worldOffsetX, 0, WORLD_WIDTH, VIEWPORT_HEIGHT);
                
                if (gameWon) {
                    drawWinMessage(g2d);
                }
            }
        };
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
    }

    private void initializeComponents() {
        setupFloorPanel();
        setupPlayer();
        setupObstacles();
        setupMonedas();
        setupMeta();
        setupLabels();
    }

    private void setupFloorPanel() {
        floorPanel = new JPanel();
        floorPanel.setBackground(Color.GREEN);
        floorPanel.setBounds(-worldOffsetX, FLOOR_Y, WORLD_WIDTH, VIEWPORT_HEIGHT - FLOOR_Y);
        contentPane.add(floorPanel);
    }

    private void setupPlayer() {
        player = new Player(WORLD_WIDTH, FLOOR_Y);
        contentPane.add(player);
    }

    private void setupObstacles() {
        obstacles = new ArrayList<>();
        obstacles.add(new Obstaculo(300, FLOOR_Y - 50));
        obstacles.add(new Obstaculo(600, FLOOR_Y - 50));
        obstacles.add(new Obstaculo(900, FLOOR_Y - 50));

        for (Obstaculo obstacle : obstacles) {
            contentPane.add(obstacle);
        }
    }

    private void setupMonedas() {
        monedas = new ArrayList<>();
        monedas.add(new Moneda(400, FLOOR_Y - 100));
        monedas.add(new Moneda(450, FLOOR_Y - 100));
        monedas.add(new Moneda(500, FLOOR_Y - 100));
        monedas.add(new Moneda(700, FLOOR_Y - 100));
        monedas.add(new Moneda(750, FLOOR_Y - 100));
        monedas.add(new Moneda(800, FLOOR_Y - 100));

        for (Moneda moneda : monedas) {
            contentPane.add(moneda);
        }
    }

    private void setupMeta() {
        meta = new Meta(WORLD_WIDTH - 100, FLOOR_Y - 50);
        contentPane.add(meta);
    }

    private void setupLabels() {
        livesLabel = new JLabel("Vidas: " + lives);
        livesLabel.setFont(new Font("Arial", Font.BOLD, 20));
        livesLabel.setBounds(10, 10, 100, 30);
        contentPane.add(livesLabel);

        coinsLabel = new JLabel("Monedas: " + coinsCollected);
        coinsLabel.setFont(new Font("Arial", Font.BOLD, 20));
        coinsLabel.setBounds(120, 10, 150, 30);
        contentPane.add(coinsLabel);
    }

    private void setupGameLoop() {
        Timer gameTimer = new Timer(16, e -> {
            if (!gameWon) {
                updateWorld();
                checkCollision();
                checkCoinCollection();
                checkWinCondition();
                contentPane.repaint();
            }
        });
        gameTimer.start();
    }

    private void setupKeyBindings() {
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (!gameWon) {
                    handleKeyPressed(e);
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (!gameWon) {
                    handleKeyReleased(e);
                }
            }
        });

        setFocusable(true);
        requestFocusInWindow();
    }

    private void handleKeyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_LEFT:
                player.moveLeft();
                break;
            case KeyEvent.VK_RIGHT:
                player.moveRight();
                break;
            case KeyEvent.VK_SPACE:
                player.jump();
                break;
            case KeyEvent.VK_CONTROL:
                player.startSprint();
                break;
        }
    }

    private void handleKeyReleased(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_LEFT:
            case KeyEvent.VK_RIGHT:
                player.stopHorizontalMovement();
                break;
            case KeyEvent.VK_CONTROL:
                player.stopSprint();
                break;
        }
    }

    private void updateWorld() {
        player.update();
        updateCameraPosition();
        updateElementPositions();
    }

    private void updateCameraPosition() {
        int playerScreenX = player.getWorldX() - worldOffsetX;
        if (playerScreenX < VIEWPORT_WIDTH / 4) {
            worldOffsetX = Math.max(0, player.getWorldX() - VIEWPORT_WIDTH / 4);
        } else if (playerScreenX > VIEWPORT_WIDTH * 3 / 4) {
            worldOffsetX = Math.min(WORLD_WIDTH - VIEWPORT_WIDTH, player.getWorldX() - VIEWPORT_WIDTH * 3 / 4);
        }
    }

    private void updateElementPositions() {
        player.setLocation(player.getWorldX() - worldOffsetX, player.getY());

        for (Obstaculo obstaculo : obstacles) {
            obstaculo.setLocation(obstaculo.getWorldX() - worldOffsetX, obstaculo.getY());
        }

        for (Moneda moneda : monedas) {
            moneda.setLocation(moneda.getWorldX() - worldOffsetX, moneda.getY());
        }

        meta.setLocation(meta.getWorldX() - worldOffsetX, meta.getY());
        floorPanel.setLocation(-worldOffsetX, FLOOR_Y);
    }

    private void checkCollision() {
        for (Obstaculo obstaculo : obstacles) {
            if (obstaculo.detectCollision(player)) {
                lives--;
                if (lives > 0) {
                    resetLevel();
                } else {
                    gameOver();
                }
                break;
            }
        }
    }

    private void checkCoinCollection() {
        ArrayList<Moneda> monedasRecolectadas = new ArrayList<>();
        for (Moneda moneda : monedas) {
            if (moneda.detectCollision(player)) {
                monedasRecolectadas.add(moneda);
            }
        }
        for (Moneda moneda : monedasRecolectadas) {
            monedas.remove(moneda);
            contentPane.remove(moneda);
            coinsCollected++;
            coinsLabel.setText("Monedas: " + coinsCollected);
        }
    }

    private void checkWinCondition() {
        if (meta.detectCollision(player)) {
            gameWon = true;
            Timer transitionTimer = new Timer(1000, e -> {
                ((Timer) e.getSource()).stop();
                dispose(); // Cerrar la ventana del nivel actual
                new Background4().setVisible(true);
            });
            transitionTimer.setRepeats(false);
            transitionTimer.start();
        }
    }

    private void gameOver() {
        JOptionPane.showMessageDialog(this, "Perdiste todas tus vidas. ¡Fin del juego!");
        System.exit(0);
    }

    private void resetLevel() {
        player.setWorldX(100);
        player.setVelocityY(0);
        player.setLocation(100, FLOOR_Y - player.getHeight());
        livesLabel.setText("Vidas: " + lives);
    }

    private void drawWinMessage(Graphics2D g2d) {
        g2d.setColor(Color.BLACK);
        g2d.setFont(new Font("Arial", Font.BOLD, 48));
        FontMetrics fm = g2d.getFontMetrics();
        String winMessage = "LEVEL 3 COMPLETE!";
        int messageWidth = fm.stringWidth(winMessage);
        g2d.drawString(winMessage, (VIEWPORT_WIDTH - messageWidth) / 2, VIEWPORT_HEIGHT / 2);
    }
}

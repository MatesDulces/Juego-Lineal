import javax.swing.JPanel;
import java.awt.Color;

public class Player extends JPanel {
    private int worldX;
    private double velocityX = 0;
    private double velocityY = 0;
    private final double GRAVITY = 0.5;
    private final double JUMP_POWER = -10;
    private final double MOVE_SPEED = 5;
    private boolean jumping = false;
    private final int FLOOR_Y;
    private final int WORLD_WIDTH;

    public Player(int worldWidth, int floorY) {
        setBackground(Color.BLUE);
        setSize(68, 68);
        this.WORLD_WIDTH = worldWidth;
        this.FLOOR_Y = floorY;
        this.worldX = 100; // Starting position
    }

    public void update() {
        worldX += velocityX;
        worldX = Math.max(0, Math.min(worldX, WORLD_WIDTH - getWidth()));

        velocityY += GRAVITY;
        
        int newY = (int) (getY() + velocityY);
        if (newY + getHeight() > FLOOR_Y) {
            newY = FLOOR_Y - getHeight();
            velocityY = 0;
            jumping = false;
        }
        
        setLocation(getX(), newY);
    }

    public void moveLeft() {
        velocityX = -MOVE_SPEED;
    }

    public void moveRight() {
        velocityX = MOVE_SPEED;
    }

    public void stopHorizontalMovement() {
        velocityX = 0;
    }

    public void jump() {
        if (!jumping && getY() + getHeight() == FLOOR_Y) {
            velocityY = JUMP_POWER;
            jumping = true;
        }
    }

    public int getWorldX() {
        return worldX;
    }
}
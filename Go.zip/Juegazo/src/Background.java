import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;

public class Background extends JFrame {

    private JPanel contentPane;
    private Player player;
    private JPanel floorPanel;
    private JPanel obstacle;
    private int worldOffsetX = 0;
    private static final int VIEWPORT_WIDTH = 1011;
    private static final int VIEWPORT_HEIGHT = 414;
    private static final int WORLD_WIDTH = 2000;
    private static final int FLOOR_Y = 319;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Background frame = new Background();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Background() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, VIEWPORT_WIDTH, VIEWPORT_HEIGHT);
        contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setColor(Color.CYAN);
                g2d.fillRect(-worldOffsetX, 0, WORLD_WIDTH, VIEWPORT_HEIGHT);
            }
        };
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        floorPanel = new JPanel();
        floorPanel.setBackground(Color.GREEN);
        floorPanel.setBounds(-worldOffsetX, FLOOR_Y, WORLD_WIDTH, VIEWPORT_HEIGHT - FLOOR_Y);
        contentPane.add(floorPanel);

        player = new Player(WORLD_WIDTH, FLOOR_Y);
        contentPane.add(player);

        obstacle = new JPanel();
        obstacle.setBackground(Color.DARK_GRAY);
        obstacle.setBounds(840 - worldOffsetX, 246, 70, 73);
        contentPane.add(obstacle);

        Timer gameTimer = new Timer(16, e -> {
            updateWorld();
            contentPane.repaint();
        });
        gameTimer.start();

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_LEFT:
                        player.moveLeft();
                        break;
                    case KeyEvent.VK_RIGHT:
                        player.moveRight();
                        break;
                    case KeyEvent.VK_SPACE:
                        player.jump();
                        break;
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_LEFT:
                    case KeyEvent.VK_RIGHT:
                        player.stopHorizontalMovement();
                        break;
                }
            }
        });

        setFocusable(true);
        requestFocusInWindow();
    }

    private void updateWorld() {
        player.update();
        
        // Update camera position
        int playerScreenX = player.getWorldX() - worldOffsetX;
        if (playerScreenX < VIEWPORT_WIDTH / 4) {
            worldOffsetX = Math.max(0, player.getWorldX() - VIEWPORT_WIDTH / 4);
        } else if (playerScreenX > VIEWPORT_WIDTH * 3 / 4) {
            worldOffsetX = Math.min(WORLD_WIDTH - VIEWPORT_WIDTH, player.getWorldX() - VIEWPORT_WIDTH * 3 / 4);
        }
        
        // Update player position on screen
        player.setLocation(player.getWorldX() - worldOffsetX, player.getY());
        
        // Update world elements
        floorPanel.setLocation(-worldOffsetX, FLOOR_Y);
        obstacle.setLocation(840 - worldOffsetX, 246);
    }
}